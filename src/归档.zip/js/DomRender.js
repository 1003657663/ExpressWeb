/**
 * Created by songchao on 16/6/14.
 */
ReactDOM.render(
    React.createElement(Login, null),
    document.getElementById("content")
);