/**
 * Created by songchao on 16/6/28.
 */

/**
 * 经理部分容器
 * 经理的职责有:
 * 增删员工,站点管理,修改快递信息
 */
var ManagerComponent = React.createClass({displayName: "ManagerComponent",
    getInititalState: function () {
        return null;
    },
    render: function () {
        return (
            React.createElement("div", null)
        );
    }
});