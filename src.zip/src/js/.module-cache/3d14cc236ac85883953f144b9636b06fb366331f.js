/**
 * Created by songchao on 16/6/14.
 */

/**
 * 分发组件到dom树
 */
ReactDOM.render(
    React.createElement(NavBar, null),
    document.getElementById("content")
);