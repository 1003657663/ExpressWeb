/**
 * Created by songchao on 16/6/15.
 */
var User = {
    isLogin:false,
    name:"",
    tel:"",
    password:""
};

var Url = {
    header:"/REST/"
};