/**
 * Created by songchao on 16/6/17.
 */
var RightComponent = React.createClass({displayName: "RightComponent",
    render: function () {
        return (
            React.createElement("div", null)
        );
    }
});