/**
 * Created by songchao on 16/6/15.
 */


/**
 * 页面中间的主要内容
 */
var Main = React.createClass({displayName: "Main",
    render: function () {
        return (
            React.createElement("div", {className: "main"})
        );
    }
});