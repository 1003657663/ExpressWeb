/**
 * Created by songchao on 16/6/16.
 */

var Footer = React.createClass({displayName: "Footer",
    render: function () {
        return (
            React.createElement("div", null)
        );
    }
});