/**
 * Created by songchao on 16/6/17.
 */

var LeftComponent = React.createClass({displayName: "LeftComponent",
    render: function () {
        return (
            React.createElement("div", {className: "left-compnonent"})
        );
    }
});